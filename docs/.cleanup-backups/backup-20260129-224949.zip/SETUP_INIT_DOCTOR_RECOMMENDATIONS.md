# Setup, Init, and Doctor: Issues and Recommendations

This document reviews issues from **tapps-agents doctor**, **bd doctor**, **tapps-agents init**, and related setup flows, and proposes concrete improvements for TappsCodingAgents.

---

## 1. Executive Summary

| Area | Key issues | Priority |
|------|------------|----------|
| **Doctor (tapps-agents)** | BEADS doesn't check PATH or suggest `set_bd_path`; SKILLS_AGENTS "no execution path" is noisy; no `--fix`/remediation runner | Medium |
| **Init** | Beads hint doesn't mention `bd doctor --fix` or PATH; `set_bd_path.ps1` not provisioned by init | Medium |
| **Beads cross-talk** | tapps doctor doesn't run or reference `bd doctor`; stealth-mode bd warnings can confuse | Low |
| **Docs** | BEADS_INTEGRATION could clarify stealth vs "Issues Tracking" bd warning; `set_bd_path` not in init/doctor flows | Low |

---

## 2. Doctor (tapps-agents)

### 2.1 BEADS: PATH and `set_bd_path`

**Issue:** When bd is available via `tools/bd` only (not on PATH), `tapps-agents doctor` reports "Available (ready)" or "Available (run `bd init`...)" but does not tell the user how to run `bd` from a terminal. Hooks and `tapps-agents beads` use `resolve_bd_path(project_root)` and work; only direct `bd` in a shell fails.

**Recommendation:**
- In `tapps_agents/core/doctor.py`, when BEADS is available:
  - If `resolve_bd_path(project_root)` is under `tools/bd` (or `tools\bd` on Windows), check whether `bd` is on `PATH` (e.g. `shutil.which("bd")`). If not, append to the remediation (or add a short second line to the message):
    - *"To run bd in terminal: add tools/bd to PATH or, if `scripts/set_bd_path.ps1` exists, run `. .\scripts\set_bd_path.ps1` (Windows) or `. ./scripts/set_bd_path.ps1` (Unix)."*
- Keep the existing remediation for `beads.enabled: false` and "bd not found" as today.

**Implementation sketch:**  
In the BEADS block, after `is_available(root)` and before building `msg`/`rem`:
- `resolved = resolve_bd_path(root)` (need to import from `..beads`; `client.resolve_bd_path`).
- If `resolved` and `"tools" in resolved and "bd" in resolved` and `not shutil.which("bd")`:
  - If `(root / "scripts" / "set_bd_path.ps1").exists()`:
    - Append to `rem` (or create `rem`) the set_bd_path sentence above.
  - Else:
    - Append: *"Add `tools/bd` to your PATH to run `bd` in terminal. See tools/README.md and docs/BEADS_INTEGRATION.md."*

---

### 2.2 BEADS: Suggest `bd doctor --fix` when `is_ready`

**Issue:** When `.beads` exists (`is_ready`), users may not know to run `bd doctor` or `bd doctor --fix` for git hooks, merge driver, etc.

**Recommendation:**
- When BEADS is **ready**, add to the BEADS finding’s `remediation` (or a brief extra line in `message`):
  - *"Run `bd doctor` for Beads-specific checks; `bd doctor --fix` to fix common issues (hooks, merge driver, etc.)."*
- Optional: only add this if `remediation` is currently `None` (e.g. when `ready` and `beads.enabled`), to avoid cluttering the "set beads.enabled" case.

---

### 2.3 SKILLS_AGENTS: "Skills with no execution path"

**Issue:** Doctor reports:  
`Skills with no execution path: backend-patterns, bug-fix-agent, coding-standards, evaluator, example-custom-skill, frontend-patterns, security-review (may be invoked via orchestrators or external tools)`.  
This is correct but can look like a problem to new users.

**Recommendations (choose one or combine):**
- **A)** Downgrade to an `info`-style severity (if doctor supports it) or leave as `warn` but make the message explicitly reassuring:
  - *"Some skills have no direct execution path (backend-patterns, bug-fix-agent, …). They are invoked via @simple-mode, orchestrators, or external tools—this is expected."*
- **B)** Add a short remediation:  
  *"Use @simple-mode *build, *fix, *review, etc., or see .cursor/rules/agent-capabilities.mdc."*
- **C)** Only emit this when the count of “no execution path” is > N (e.g. 5) to reduce noise, or when a user-focused verbosity flag is set.

---

### 2.4 Doctor: `--fix` or remediation runner

**Issue:** `bd doctor --fix` can auto-fix several items; `tapps-agents doctor` only reports. Users must manually run remediations.

**Recommendation (optional, larger change):**
- Add `tapps-agents doctor --fix` or `--suggest-fixes` that:
  - Prints a list of remediations (and, where safe, one-line commands) for each `warn`/`error` finding.
  - For BEADS: when `is_available` and not `is_ready`, suggest:  
    `bd init --stealth` (or `bd init`).  
  - When `is_ready` and bd not on PATH and `scripts/set_bd_path.ps1` exists:  
    suggest `. .\scripts\set_bd_path.ps1` or `.\scripts\set_bd_path.ps1 -Persist`.
- Do not auto-execute without a prompt or `--yes`; keep `doctor` default as read-only.

---

## 3. Init

### 3.1 Beads hint: `bd init` and `bd doctor --fix`

**Issue:** `_print_next_steps` says *"Run `bd init` or `bd init --stealth` to enable Beads"* when `is_available` and not `is_ready`, but does not mention `bd doctor --fix` after init. Users who run `bd init` may then wonder about hooks, merge driver, PATH, etc.

**Recommendation:**
- When `is_available` and not `is_ready`, extend the existing beads line to:
  - *"Run `bd init` or `bd init --stealth` to enable Beads for this project. Then run `bd doctor --fix` to install hooks and fix common issues. See docs/BEADS_INTEGRATION.md."*

---

### 3.2 Beads hint: PATH and `set_bd_path` when ready

**Issue:** When `is_ready`, the message is *"Beads is ready. Use `bd ready` to see unblocked tasks."* Users may try `bd ready` in a new terminal and fail if `bd` is not on PATH.

**Recommendation:**
- When `is_available` and `is_ready`:
  - If `scripts/set_bd_path.ps1` exists:  
    *"Beads is ready. Use `bd ready` to see unblocked tasks. To use `bd` in terminal: run `. .\scripts\set_bd_path.ps1` (Windows) or `. ./scripts/set_bd_path.ps1` (Unix), or add tools/bd to PATH."*
  - Else:  
    *"Beads is ready. Use `bd ready` to see unblocked tasks. Add tools/bd to PATH to run `bd` in terminal. See tools/README.md."*

---

### 3.3 Init: Provision `set_bd_path.ps1`

**Issue:** `scripts/set_bd_path.ps1` is maintained in this repo and documented in `tools/README.md` and BEADS_INTEGRATION, but `tapps-agents init` does not create it. Projects that adopt `tools/bd` (or that get it from a template) have no standard way to put `bd` on PATH.

**Recommendation:**
- Add a resource `tapps_agents/resources/scripts/set_bd_path.ps1` (or similar) with the same behavior as the current `scripts/set_bd_path.ps1` (project-root-agnostic, using `$PSScriptRoot` to find `tools/bd`).
- In `init_project` (or in a post-init step invoked from `handle_init_command`):
  - If `(project_root / "tools" / "bd").exists()` and `(project_root / "tools" / "bd" / "bd.exe").exists()` or `(project_root / "tools" / "bd" / "bd").exists()`:
    - Ensure `project_root / "scripts"` exists.
    - Copy the resource `set_bd_path.ps1` to `project_root / "scripts" / "set_bd_path.ps1` if it does not already exist (or only if `--reset` and we own it; otherwise preserve user file).
- Document in BEADS_INTEGRATION and `command-reference.mdc` that `init` may create `scripts/set_bd_path.ps1` when `tools/bd` is present.

**Alternative (lighter):** Do not ship the script; only document in init’s beads hint: *"A script to add bd to PATH is in docs/BEADS_INTEGRATION.md (or tools/README.md)."* with a link to a copy-paste or curl. The above is preferred for a smoother first-run experience.

---

### 3.4 Init: Offer to run `bd init` when bd is available

**Issue:** Init only suggests `bd init`; it does not run it. Some users might prefer a one-step: init + bd init.

**Recommendation (optional):**
- When `is_available` and not `is_ready` and not `getattr(args, "yes", False)`:
  - After the beads hint, prompt: *"Run `bd init --stealth` now? [y/N]:"*. If `y`, run `run_bd(project_root, ["init", "--stealth"], capture_output=False)` (or equivalent), then briefly report success/failure.
- With `--yes`, skip the prompt; optionally do not run `bd init` to avoid side effects in non-interactive use.  
- This is optional; the existing hint may be enough.

---

## 4. Beads vs Tapps Doctor (cross-cutting)

### 4.1 tapps-agents doctor does not run `bd doctor`

**Issue:** Beads-specific checks (git hooks, merge driver, sync-branch, issues.jsonl, etc.) live in `bd doctor`. `tapps-agents doctor` does not call it, so users must remember to run both.

**Recommendation:**
- **Light:** In the BEADS finding, when `is_ready`, add:  
  *"Run `bd doctor` for Beads-specific checks; `bd doctor --fix` to fix."*  
  (Already proposed in §2.2.)
- **Heavier (optional):** Add `tapps-agents doctor --with-bd` that, when `is_ready`, runs `bd doctor` and appends a short summary (e.g. pass/warn counts) to the report. Avoid running `bd doctor --fix` automatically.

---

### 4.2 bd doctor: "Issues Tracking: issues.jsonl is ignored by git"

**Issue:** In stealth mode, `.beads/` is in `.gitignore` or `.git/info/exclude`, so `issues.jsonl` is intentionally not tracked. bd doctor still warns; this can confuse users of TappsCodingAgents who use `bd init --stealth`.

**Recommendation:**
- In **BEADS_INTEGRATION.md**, add a short subsection, e.g. "Stealth mode and bd doctor":
  - In stealth, `.beads/` is not committed; `bd sync` and "Issues Tracking" do not apply. The bd doctor warning *"issues.jsonl is ignored by git (bd sync will fail)"* is expected and can be ignored when using `bd init --stealth`.
- Optionally: in the BEADS doctor finding when we detect stealth (e.g. `.beads` exists and `.gitignore` or `.git/info/exclude` contains `.beads/`), we could add a note. That requires more detection logic; the doc change is likely enough.

---

### 4.3 bd doctor: "Claude Integration: Not configured"

**Issue:** bd doctor suggests Claude plugin / `bd setup claude`. TappsCodingAgents is used in Cursor; that suggestion is irrelevant here.

**Recommendation:**
- No code change. In BEADS_INTEGRATION, mention that when using Cursor, "Claude Integration" and related bd doctor hints can be ignored. Optional: *"For Cursor, `tapps-agents` and `@simple-mode` provide the integration; `bd setup claude` is for Claude Code."*

---

## 5. Documentation

### 5.1 BEADS_INTEGRATION.md

- **Stealth and bd doctor:** Add the "Stealth mode and bd doctor" note as in §4.2.
- **set_bd_path and PATH:** In "Installing bd" or a new "PATH and scripts" subsection:
  - If the project has `tools/bd`, add `tools/bd` to PATH or use `scripts/set_bd_path.ps1` if present.  
  - If `tapps-agents init` is updated to provision `set_bd_path.ps1` (§3.3), say that init may create `scripts/set_bd_path.ps1` when `tools/bd` exists.
- **Doctor and init:** In "Doctor and Init":
  - `tapps-agents doctor`: when Beads is ready, run `bd doctor` for Beads-specific checks; `bd doctor --fix` to fix. If `bd` is only under `tools/bd`, add `tools/bd` to PATH or use `scripts/set_bd_path.ps1`.
  - `tapps-agents init`: after `bd init` (or `bd init --stealth`), run `bd doctor --fix`; use `set_bd_path.ps1` or PATH to run `bd` in terminal.

---

### 5.2 command-reference.mdc and AGENTS.md

- **Init:** In the "Beads (bd) hint" / "Init and doctor" descriptions, add that init may suggest or create `scripts/set_bd_path.ps1` when `tools/bd` exists (if §3.3 is done), and that users should run `bd doctor --fix` after `bd init`.
- **Doctor:** In the doctor section, note that when Beads is ready, `bd doctor` (and `bd doctor --fix`) are recommended for Beads-specific checks and fixes.

---

### 5.3 tools/README.md

- Already documents `set_bd_path.ps1` and when to use it. If init starts provisioning it, add: *"This script may be created by `tapps-agents init` when `tools/bd` is present."*

---

## 6. Implementation Priority

| # | Change | Effort | Impact |
|---|--------|--------|--------|
| 1 | BEADS remediation: PATH / `set_bd_path` when bd under `tools/bd` and not on PATH (§2.1) | Low | High |
| 2 | BEADS remediation: suggest `bd doctor` / `bd doctor --fix` when `is_ready` (§2.2) | Low | Medium |
| 3 | Init: extend beads hint with `bd doctor --fix` when not `is_ready` (§3.1) | Low | Medium |
| 4 | Init: extend beads hint with PATH / `set_bd_path` when `is_ready` (§3.2) | Low | Medium |
| 5 | BEADS_INTEGRATION: stealth and bd doctor (§4.2, §5.1) | Low | Medium |
| 6 | SKILLS_AGENTS: soften message or add remediation (§2.3) | Low | Low |
| 7 | Init: provision `scripts/set_bd_path.ps1` when `tools/bd` exists (§3.3) | Medium | High |
| 8 | Doctor: `--fix` / `--suggest-fixes` (§2.4) | Medium | Medium |
| 9 | doctor `--with-bd` or similar (§4.1) | Low–Medium | Low |
| 10 | Init: optional prompt to run `bd init --stealth` (§3.4) | Low | Low |

---

## 7. References

- `tapps_agents/core/doctor.py` – BEADS block (~830–895), `collect_doctor_report`, `DoctorFinding`
- `tapps_agents/beads/client.py` – `is_available`, `is_ready`, `resolve_bd_path`
- `tapps_agents/cli/commands/top_level.py` – `_print_next_steps`, `handle_init_command`, `_run_environment_check`
- `tapps_agents/core/init_project.py` – `init_project`, what gets copied/created
- `docs/BEADS_INTEGRATION.md` – Beads config, doctor/init, PATH
- `tools/README.md` – running bd, `set_bd_path.ps1`
- `scripts/set_bd_path.ps1` – current project script (candidate for `tapps_agents/resources/scripts/`)
