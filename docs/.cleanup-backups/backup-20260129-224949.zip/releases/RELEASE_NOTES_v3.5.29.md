# Release 3.5.29 - 2026-01-23

## Version Update

This release updates the version to 3.5.29.

### Changed

- Version bump to 3.5.29

---

**Full Changelog**: https://github.com/wtthornton/TappsCodingAgents/blob/main/CHANGELOG.md#3529---2026-01-23
