# Batch Results

Total files: 2

## File 1: C:\cursor\TappsCodingAgents\tapps_agents\core\agent_base.py

### Scores
- **Overall**: 85.2/100
- **Complexity**: 2.6/10
- **Security**: 10.0/10
- **Maintainability**: 8.9/10

## File 2: C:\cursor\TappsCodingAgents\tapps_agents\context7\library_detector.py

### Scores
- **Overall**: 68.2/100
- **Complexity**: 2.6/10
- **Security**: 10.0/10
- **Maintainability**: 7.2/10
